import numpy as np
import cv2 as cv
import math
import grey_conversion as grey_cv
import utils
import umbral
 
def entropy(gray):
    p = [] # Probabilidad gris
    
    H_last = 0 # Entropía total de la última H
    best_k = 0 # Mejor umbral
    hist = cv2.calcHist ([gray], [0], None, [256], [0,256]) # 255 * 1 matriz de histograma gris
    for i in range(256):
        p.insert(i,hist[i][0]/gray.size)
    for k in range(256):
        H_b = 0 # entropía del negro, la cantidad promedio de información en primer plano
        H_w = 0 # La entropía del blanco, la cantidad promedio de información de fondo
        for i in range(k):
            if p[i] != 0:
                H_b = H_b - p[i]*math.log(2,p[i])
        
        for i in range(k,256):
            if p[i] != 0:
                H_w = H_w - p[i]*math.log(2,p[i])
           
        H = H_b + H_w
        if H>H_last:
            H_last = H
            best_k = k
      
    return best_k

def main():
  img = cv.imread("mina_cortada.png")
  grey_img = grey_cv.convert_to_greyscale(img)
  width = img.shape[1]
  height = img.shape[0]
  print("Elige el espacio de la imagen a cortar")
  a,b,c,d = utils.choose_image_section(width, height)
  cut_img = grey_img[c:d,a:b]
  # k is the alpha cut value
  #cut_img = [[127,122,177,189],[85,73,127,139],[75,61,102,128],[58,40,84,108]]
  cut_img = np.array(cut_img)
  flattened = cut_img.flatten()
  sorted_img = np.unique(flattened)
  N = len(flattened)
  umbral_values = []
  for i in range(1,len(sorted_img)):
    eta_value = Entropy(cut_img,flattened,i,N,sorted_img)
    umbral_values.append(eta_value)
  best_eta_idx = np.where( umbral_values == min(umbral_values))[0][0]
  best_umbral = sorted_img[best_eta_idx]
  print(umbral_values)
  print(best_umbral)
  #Retorna el mejor umbral y llama a función de umbral con este valor
  umbral_img = umbral.umbral_selection(cut_img, best_umbral)
  utils.print_matrix("mina_umbral_variance.csv",umbral_img)
  cv.imwrite("mina_umbral_variance.png",umbral_img)

if __name__ == '__main__':
  main()
